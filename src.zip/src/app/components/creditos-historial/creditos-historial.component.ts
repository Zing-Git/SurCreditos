import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-creditos-historial',
  templateUrl: './creditos-historial.component.html'
})
export class CreditosHistorialComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
