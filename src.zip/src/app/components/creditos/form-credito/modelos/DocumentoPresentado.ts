export class DocumentoPresentado {
  nombre: string;
  requerido: boolean;
  presentado = false;
}
