export interface TablePlanCuotas {
  orden;
  montoCapital;
  vencimiento;
  montoInteres;
  montoCobranzaADomicilio;
  MontoTotalCuota;
}
