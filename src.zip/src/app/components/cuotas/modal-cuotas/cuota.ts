export class Cuota {
    _id: string;
    diasRetraso: number;
    montoInteresPorMora: number;
    montoPagado: number;
    porcentajeInteresPorMora: number;
    comentario: string;
    montoPendienteDePago: number;
    todosMontoPagoActual: string;
    MontoTotalCuota: string;
    orden: string;
    //orden: number;
   /* montoPendienteDePago: number;
    orden:number;
    cuotaPagada: boolean;
    MontoTotalCuota: number;
    fechaVencimiento: string;
*/
   
}