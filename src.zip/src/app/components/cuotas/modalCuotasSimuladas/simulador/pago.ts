import { Cuota } from "../../modal-cuotas/cuota";

export class Pago{
    token: string;
    cuotas: any[];
}