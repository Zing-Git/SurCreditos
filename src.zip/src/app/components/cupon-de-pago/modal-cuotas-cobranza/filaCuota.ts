

export class FilaCuota {
  orden: number;
  montoPagado: number;
  montoPendienteDePago: number;
  MontoTotalCuota: number;

}
