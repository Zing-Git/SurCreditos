import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-modal-cuotas-cobro',
  templateUrl: './modal-cuotas-cobro.component.html'
})
export class ModalCuotasCobroComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
