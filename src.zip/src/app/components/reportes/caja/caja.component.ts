import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-caja',
  templateUrl: './caja.component.html',
})
export class CajaComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
