import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-financieros',
  templateUrl: './financieros.component.html',
})
export class FinancierosComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
