import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-opertativos',
  templateUrl: './opertativos.component.html',

})
export class OpertativosComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
