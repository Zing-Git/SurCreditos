export interface Table {
  id: Number;
  name: String;
  age: Number;
/*   test: {
    valor: string
  }; */
}
