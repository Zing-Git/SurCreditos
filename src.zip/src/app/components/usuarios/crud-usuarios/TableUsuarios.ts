export interface TableUsuarios {
  _id: string;
  dni: string;
  nombreUsuario: string;
  estado: boolean;
  apellidos: string;
  nombres: string;
  rol: string;
}

