import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-form-cambio-clave',
  templateUrl: './form-cambio-clave.component.html',
})
export class FormCambioClaveComponent implements OnInit {

  constructor() { }

  ngOnInit() {

  }

}
