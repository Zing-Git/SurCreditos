"use strict";
exports.__esModule = true;
var Comercio = /** @class */ (function () {
    function Comercio() {
    }
    return Comercio;
}());
exports.Comercio = Comercio;
