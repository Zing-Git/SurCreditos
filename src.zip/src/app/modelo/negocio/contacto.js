"use strict";
exports.__esModule = true;
var Contacto = /** @class */ (function () {
    function Contacto(values) {
        if (values === void 0) { values = {}; }
        // Constructor initialization
        Object.assign(this, values);
    }
    return Contacto;
}());
exports.Contacto = Contacto;
