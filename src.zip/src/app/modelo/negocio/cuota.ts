export class Cuota {
    cuotaPagada: boolean;
    montoPagado: string;
    diasRetraso: number;
    comentarios: string[];
    _id: string;
    orden: number;
    montoCapital: string;
    montoInteres: string;
    montoCobranzaADomicilio: string;
    MontoTotalCuota: string;
    fechaVencimiento: string;
    montoPendienteDePago: string;
    __v: number;

    
}