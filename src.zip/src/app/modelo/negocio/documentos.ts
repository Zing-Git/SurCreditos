export class Documentos{
    _id: string;
    nombre: string;
    requerido:boolean;
    presentado:boolean;
    __v: number;
}