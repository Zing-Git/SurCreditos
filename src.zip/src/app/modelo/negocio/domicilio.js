"use strict";
exports.__esModule = true;
var Domicilio = /** @class */ (function () {
    function Domicilio(values) {
        if (values === void 0) { values = {}; }
        // Constructor initialization
        Object.assign(this, values);
    }
    return Domicilio;
}());
exports.Domicilio = Domicilio;
