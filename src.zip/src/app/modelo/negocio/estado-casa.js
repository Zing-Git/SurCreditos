"use strict";
exports.__esModule = true;
var EstadoCasa = /** @class */ (function () {
    function EstadoCasa(values) {
        if (values === void 0) { values = {}; }
        // Constructor initialization
        Object.assign(this, values);
    }
    return EstadoCasa;
}());
exports.EstadoCasa = EstadoCasa;
