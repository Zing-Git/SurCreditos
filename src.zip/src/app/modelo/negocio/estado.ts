export class Estado{
    _id: string;
    nombre: string;
    orden:number;
    estadoTerminal:boolean;
    __v: number;
}