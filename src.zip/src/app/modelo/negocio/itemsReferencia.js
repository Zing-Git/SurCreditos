"use strict";
exports.__esModule = true;
var ItemsReferencia = /** @class */ (function () {
    function ItemsReferencia() {
    }
    return ItemsReferencia;
}());
exports.ItemsReferencia = ItemsReferencia;
