export class Provincia {
  iso_31662: string;
  provincia: string;
  capital: string;
  localidad: string[];
}
