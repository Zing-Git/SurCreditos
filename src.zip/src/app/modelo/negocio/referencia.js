"use strict";
exports.__esModule = true;
var Referencia = /** @class */ (function () {
    function Referencia() {
    }
    return Referencia;
}());
exports.Referencia = Referencia;
