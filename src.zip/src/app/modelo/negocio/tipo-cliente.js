"use strict";
exports.__esModule = true;
var TipoCliente = /** @class */ (function () {
    function TipoCliente() {
    }
    return TipoCliente;
}());
exports.TipoCliente = TipoCliente;
