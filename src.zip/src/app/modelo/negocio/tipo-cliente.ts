export class TipoCliente{
    _id: string;
    nombre: string;
    __v: number;
}