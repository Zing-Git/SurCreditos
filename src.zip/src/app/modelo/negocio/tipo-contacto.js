"use strict";
exports.__esModule = true;
var TipoContacto = /** @class */ (function () {
    function TipoContacto(values) {
        if (values === void 0) { values = {}; }
        // Constructor initialization
        Object.assign(this, values);
    }
    return TipoContacto;
}());
exports.TipoContacto = TipoContacto;
