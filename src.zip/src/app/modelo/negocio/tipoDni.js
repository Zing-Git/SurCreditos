"use strict";
exports.__esModule = true;
var TipoDni = /** @class */ (function () {
    function TipoDni(values) {
        if (values === void 0) { values = {}; }
        // Constructor initialization
        Object.assign(this, values);
    }
    return TipoDni;
}());
exports.TipoDni = TipoDni;
