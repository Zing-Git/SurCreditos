"use strict";
exports.__esModule = true;
var TipoReferencia = /** @class */ (function () {
    function TipoReferencia() {
    }
    return TipoReferencia;
}());
exports.TipoReferencia = TipoReferencia;
