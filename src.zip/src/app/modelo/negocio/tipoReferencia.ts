export class TipoReferencia{
    _id:string;
    nombre:string;
    orden:number;
    __v:number;
}