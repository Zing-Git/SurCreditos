"use strict";
exports.__esModule = true;
var Titular = /** @class */ (function () {
    function Titular() {
    }
    return Titular;
}());
exports.Titular = Titular;
