export class TokenPost {
  token: string;
  constructor(values: Object = {}) {
    // Constructor initialization
    Object.assign(this, values);
  }
}
