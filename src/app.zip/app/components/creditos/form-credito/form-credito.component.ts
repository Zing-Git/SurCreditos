import { Component, OnInit } from '@angular/core';
import { ClientesService } from '../../../modules/servicios/clientes/clientes.service';
import { Session } from '../../../modelo/util/session';
import { LoginService } from '../../../modules/servicios/login/login.service';
import { FormGroup, FormBuilder, FormControl, Validators, FormArray } from '@angular/forms';
import { UtilidadesService } from '../../../modules/servicios/utiles/utilidades.service';
import { CreditosService } from '../../../modules/servicios/creditos/creditos.service';
import { TablePlanCuotas } from './TablePlanCuotas';
import { formatNumber } from '@angular/common';
import { DatePipe } from '@angular/common';


@Component({
  selector: 'app-form-credito',
  templateUrl: './form-credito.component.html'
})
export class FormCreditoComponent implements OnInit {
  session: Session;
  creditoForm: FormGroup;
  currentJustify = 'justified';
  tiposPlanes: any[];
  tiposReferencias: any[];
  planes: any[];
  referenciaComercios = [];
  referenciaTitulares = [];
  controls = [];
  documentosAPresentar = [];
  tipoPlanElegido: any;
  planElegido: any;

  characters: TablePlanCuotas[];

  settings = {

    actions: {
      columnTitle: '',
      add: false,
      delete: false,
      edit: false,
      imprimirPDF: false,
      position: 'right',
      custom: [],
    },
    columns: {
      orden: {
        title: 'Ord.',
        width: '5%',
        filter: false,
      },
      montoCapital: {
        title: 'Capital',
        width: '15%',
        filter: false,
        valuePrepareFunction: (value) => {
          return value === 'montoCapital' ? value : Intl.NumberFormat('es-AR', {style: 'currency', currency: 'ARS'}).format(value);
        }
      },
      vencimiento: {
        title: 'Vencimiento',
        width: '15%',
        filter: false,
        valuePrepareFunction: (date) => {
          let raw = new Date(date);
          let formatted = this.datePipe.transform(raw, 'dd/MM/yyyy');
          return formatted;
        }
      },
      montoInteres: {
        title: 'Interes',
        width: '15%',
        filter: false,
        valuePrepareFunction: (value) => {
          return value === 'montoInteres' ? value : Intl.NumberFormat('es-AR', {style: 'currency', currency: 'ARS'}).format(value);
        }
      },
      montoCobranzaADomicilio: {
        title: 'Adic. cobro Domic.',
        width: '20%',
        filter: false,
        valuePrepareFunction: (value) => {
          return value === 'montoCobranzaADomicilio' ? value : Intl.NumberFormat('es-AR', {style: 'currency', currency: 'ARS'}).format(value);
        }
      },
      MontoTotalCuota: {
        title: 'Total Cuota',
        width: '30%',
        filter: false,
        valuePrepareFunction: (value) => {
          return value === 'MontoTotalCuota' ? value : Intl.NumberFormat('es-AR', {style: 'currency', currency: 'ARS'}).format(value);
        }
      }
    },
    pager: {
      display: true,
      perPage: 8
    },
  };



  documentaciones = [
    { id: 100, name: 'DNI Titular' },
    { id: 200, name: 'Impuesto 1' },
    { id: 300, name: 'Impuesto 2' },
    { id: 400, name: 'Otra' }
  ];

  planPago = {
    montoSolicitado: '',
    cobranzaEnDomicilio: false,
    cantidadCuotas: 0,
    tasa: 0,
    diasASumar: 0
  };


  constructor(
      private fb: FormBuilder,
      private clientesService: ClientesService,
      private loginService: LoginService,
      private utilidadesService: UtilidadesService,
      private creditosService: CreditosService,
      private datePipe: DatePipe ) { }

  ngOnInit() {
    this.session = new Session();
    this.session.token = this.loginService.getTokenDeSession();
    this.cargarControlesForm();


    // Create a new array with a form control for each order
    this.controls = this.documentaciones.map(c => new FormControl(false));
    this.controls[0].setValue(true); // Set the first checkbox to true (checked)



    this.creditoForm = this.fb.group({
      dni: new FormControl('', [Validators.required]),
      apellidos: new FormControl('', [Validators.required]),
      nombres: new FormControl('', [Validators.required]),
      fechaNacimiento: new FormControl('', [Validators.required]),

      montoSolicitado: new FormControl('', [Validators.required]),
      tipoDePlan: new FormControl('', [Validators.required]),
      plan: new FormControl('', [Validators.required]),
      cobroDomicilio: new FormControl(false),

      dniGarante: new FormControl('', [Validators.required]),
      apellidosGarante: new FormControl('', [Validators.required]),
      nombresGarante: new FormControl('', [Validators.required]),
      fechaNacimientoGarante: new FormControl('', [Validators.required]),
      cuit: new FormControl(''),
      razonSocial: new FormControl(''),

      // array de checkbox dinamico
      documentaciones: new FormArray(this.controls),
      numeroLegajo:  new FormControl('', [Validators.required]),
      tipoReferenciaTitular: new FormControl('', [Validators.required]),
      itemsReferenciasTitular: new FormArray(this.controls),
      notaComentarioTitular: new FormControl('', [Validators.required]),

      tipoReferenciaComercio: new FormControl('', [Validators.required]),
      itemsReferenciasGarante: new FormArray(this.controls),
      notaComentarioComercio: new FormControl(''),


    });
  }
  get dni() {    return this.creditoForm.get('dni');  }
  get apellidos() {    return this.creditoForm.get('apellidos');  }
  get nombres() {    return this.creditoForm.get('nombres');  }
  get fechaNacimiento() {    return this.creditoForm.get('fechaNacimiento');  }
  get montoSolicitado() {    return this.creditoForm.get('montoSolicitado');  }
  get tipoDePlan() {    return this.creditoForm.get('tipoDePlan');  }
  get plan() {    return this.creditoForm.get('plan');  }
  get cobroDomicilio() {    return this.creditoForm.get('cobroDomicilio');  }
  get dniGarante() {    return this.creditoForm.get('dniGarante');  }
  get apellidosGarante() {    return this.creditoForm.get('apellidosGarante');  }
  get nombresGarante() {    return this.creditoForm.get('nombresGarante');  }
  get fechaNacimientoGarante() {    return this.creditoForm.get('fechaNacimientoGarante');  }
  get cuit() {    return this.creditoForm.get('cuit');  }
  get razonSocial() {    return this.creditoForm.get('razonSocial');  }


  /* get documentacion() {    return this.creditoForm.get('documentacion');  } */
  get numeroLegajo() {    return this.creditoForm.get('numeroLegajo');  }
  get tipoReferenciaTitular() {    return this.creditoForm.get('tipoReferenciaTitular');  }
  get itemsReferenciasTitular() {    return this.creditoForm.get('itemsReferenciasTitular');  }
  get notaComentarioTitular() {    return this.creditoForm.get('notaComentarioTitular');  }
  get tipoReferenciaComercio() {    return this.creditoForm.get('tipoReferenciaGarante');  }
  get itemsReferenciasGarante() {    return this.creditoForm.get('itemsReferenciasGarante');  }
  get notaComentarioComercio() {    return this.creditoForm.get('notaComentarioGarante');  }







  onFormSubmit() {
    // toma los valores de los checkbox cargados dinamicamente:
    const selectedOrderIds = this.creditoForm.value.documentaciones
      .map((v, i) => v ? this.documentaciones[i].id : null)
      .filter(v => v !== null);

      // console.log(selectedOrderIds);


  }

  verClientes() {
    this.session  = new Session();
    this.session.token =  this.loginService.getTokenDeSession();
    this.clientesService.postGetClientes(this.session).subscribe( response => {
        let clientes = response['clientes'];
        console.log(clientes);
    });
  }
  buscarClientePorDni() {
    let dni = this.dni.value;
    this.session  = new Session();
    this.session.token =  this.loginService.getTokenDeSession();
    this.clientesService.postGetClientePorDni(this.session, dni).subscribe( response => {
        let cliente = response['clientes'];
        console.log(cliente[0]);
        this.cargarClienteForm(cliente[0]);
    });
  }
  cargarClienteForm(cliente: any) {
    this.apellidos.setValue(cliente.titular.apellidos);
    this.nombres.setValue(cliente.titular.nombres);
    this.fechaNacimiento.setValue(this.utilidadesService.formateaDateAAAAMMDD(cliente.titular.fechaNacimiento));
  }


  cargarControlesForm() {
    this.clientesService.postGetCombos().subscribe( response => {
      let combos = response['respuesta'];
     /*  console.log(combos); */

      // Carga de compos de Tipos de Planes
      this.tiposPlanes = response['respuesta'].tiposPlanes;

      // Tipo de Referencia: Buena - Mala - Regular
      this.tiposReferencias = response['respuesta'].tiposReferencias;



      // Carga de combos de referencias
      let referencias = response['respuesta'].itemsReferencia;
      for (let ref of referencias) {
        if (ref.referenciaCliente) {
          this.referenciaTitulares.push(ref);
        } else {
          this.referenciaComercios.push(ref);
        }
      }



      // Carga de Checkbox de Documentacion Presentada
      this.documentosAPresentar = response['respuesta'].documentos;
      // console.log(this.documentosAPresentar);
    });

  }

  changeCheckboxDocumentacion(i) {
    if (this.documentosAPresentar) {
      this.documentosAPresentar[i].requerido = !this.documentosAPresentar[i].requerido;
      console.log(this.documentosAPresentar[i]);
    }
  }
  changeCheckboxReferenciaTitular(i){
    if (this.referenciaTitulares) {
      this.referenciaTitulares[i].referenciaCliente = !this.referenciaTitulares[i].referenciaCliente;
      let itemRTElegido = {
        item: this.referenciaTitulares[i].item,
        checkboxElegido: !this.referenciaTitulares[i].referenciaCliente,
      }
      console.log(this.referenciaTitulares[i]);
      console.log(itemRTElegido.checkboxElegido);
    }
  }

  changeCheckboxReferenciaComercio(i){
    this.referenciaComercios[i].referenciaCliente = !this.referenciaComercios[i].referenciaCliente;
    if (this.referenciaComercios) {
      let itemRTElegido = {
        item: this.referenciaComercios[i].item,
        checkboxElegido: this.referenciaComercios[i].referenciaCliente,
      }
      console.log(this.referenciaComercios[i]);
      console.log(itemRTElegido.checkboxElegido);
    }
  }

  calcularPlanDePago() {

    this.planPago = {
      montoSolicitado: this.montoSolicitado.value,
      cobranzaEnDomicilio: this.cobroDomicilio.value,
      cantidadCuotas: this.plan.value,
      tasa: this.planElegido.tasa,
      diasASumar: this.tipoPlanElegido.diasASumar,
    };

    console.log(this.planPago);

      this.creditosService.postGetPlanDePago(this.planPago).subscribe( response => {
          let p = response['planPago'];
          console.log(p);
         // Asignacion para cargar la tabla de datos
         this.characters = p.planPagos;
      });

  }


  onChangeTipoPlanes() {
    this.tipoPlanElegido =  this.tiposPlanes.find(x => x.nombre === this.creditoForm.get('tipoDePlan').value);
    this.planes = this.tipoPlanElegido.plan;

    /* let xTiposPlanesDiasASumar = planes.diasASumar;
    let xTiposPlanes_id = planes._id;
    console.log(xTiposPlanesDiasASumar, ' -- ', xTiposPlanes_id); */


  }

  onChangePlanes() {
    let planCuotaElegido = parseInt(this.creditoForm.get('plan').value, 10);
    this.planElegido =  this.planes.find(x => x.cantidadCuotas === planCuotaElegido);

   /*  console.log(this.planElegido.tasa);
    console.log(this.planElegido._id);
    console.log(this.planElegido.cantidadCuotas); */

  }

  buscarComercioPorCuit() {

  }

  buscarGarantePorDni() {

  }

}
