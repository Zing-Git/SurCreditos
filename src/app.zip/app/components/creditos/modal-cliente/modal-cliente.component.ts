import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-modal-cliente',
  templateUrl: './modal-cliente.component.html',
  styleUrls: ['./modal-cliente.component.css']
})
export class ModalClienteComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
