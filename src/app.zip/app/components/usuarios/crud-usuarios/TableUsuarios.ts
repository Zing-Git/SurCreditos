export interface TableUsuarios {
  _id: string;
  dni: string;
  nombreUsuario: string;
  estado: boolean;
}

