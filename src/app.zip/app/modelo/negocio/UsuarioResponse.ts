export class UsuarioResponse{

  /*

    "usuarios": [
        {
            "contactos": [
                {
                    "_id": "5b1fd58d8bb8104573d030aa",
                    "tipoContacto": {
                        "_id": "5b10071f42fb563dffcf6b8d",
                        "nombre": "Telefono fijo",
                        "__v": 0
                    },
                    "codigoPais": "+54",
                    "codigoArea": "388",
                    "numeroFijo": "4076852",
                    "__v": 0
                },
                {
                    "_id": "5b1fd5dd8bb8104573d030ac",
                    "tipoContacto": {
                        "_id": "5b10071f42fb563dffcf6b8c",
                        "nombre": "Telefono Celular",
                        "__v": 0
                    },
                    "codigoPais": "+549",
                    "codigoArea": "388",
                    "numeroCelular": "6011952",
                    "__v": 0
                },
                {
                    "_id": "5b1fd5fd8bb8104573d030ae",
                    "tipoContacto": {
                        "_id": "5b10071f42fb563dffcf6b8e",
                        "nombre": "Email",
                        "__v": 0
                    },
                    "email": "om4r.gonzalez@gmail.com",
                    "__v": 0
                }
            ],
            "_id": "5b1fd9d10939a44ff6240359",
            "persona": {
                "_id": "5b1fc0cb622be630ba2147cb",
                "tipoDni": {
                    "_id": "5b0d6a845b9d842646da57c9",
                    "nombre": "DNI",
                    "__v": 0
                },
                "dni": "28462285",
                "apellidos": "Musk",
                "nombres": "Elon Reeve",
                "domicilio": {
                    "_id": "5b1ed4fa68759d1913988b34",
                    "pais": "Argentina",
                    "provincia": "Jujuy",
                    "localidad": "Abra Pampa",
                    "barrio": "Santa Rita",
                    "calle": "Pablo Arroyo",
                    "numeroCasa": "521",
                    "estadoCasa": {
                        "_id": "5b18a965a04a411ac18bdef2",
                        "nombre": "Propia",
                        "__v": 0
                    },
                    "__v": 0
                },
                "fechaNacimiento": "1980-05-02T00:00:00.000Z",
                "fechaAlta": "2018-06-12T12:47:07.591Z",
                "__v": 0
            },
            "nombreUsuario": "elonnn",
            "clave": "elon123",
            "rol": {
                "_id": "5b211fecbac3952988ca92b1",
                "nombre": "VENDEDOR",
                "precedencia": 3,
                "__v": 0
            },
            "__v": 1
        },
        {
            "contactos": [],
            "_id": "5b28a3938200f10014aaf6aa",
            "nombreUsuario": "fdffddffd",
            "clave": "$2b$10$wNIE4WmrBqPpn5DOKn51WuyMkllfu4bUugOi3ZYD7ecUmOl1K/5vi",
            "rol": {
                "_id": "5b211fecbac3952988ca92b1",
                "nombre": "VENDEDOR",
                "precedencia": 3,
                "__v": 0
            },
            "__v": 0
        }
    ]
} */

}
