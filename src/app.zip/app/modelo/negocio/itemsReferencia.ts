export class ItemsReferencia{
    _id: string;
    item: string;
    referenciaCliente: boolean;
    __v: number;
}