import { Injectable } from '@angular/core';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { Session } from '../../../modelo/util/session';
import { Observable } from 'rxjs';


const cudOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' }),
};
const cudOptionsXWWForm = {
  headers: new HttpHeaders({ 'Content-Type': 'application/x-www-form-urlencoded'})
};
const cudOptionsHtml = {
  headers: new HttpHeaders({ 'Content-Type': 'text/html; charset=utf-8'})
};


@Injectable({
  providedIn: 'root'
})
export class CreditosService {
  public urlBase = 'https://ws-sur-creditos.herokuapp.com';
   // GET URLs
   public urlPostGetPlanDePago = this.urlBase + '/credito/calcular_plan_pago/';



  constructor(public http: HttpClient) { }

  // POST: Obtiene todos los clientes
  postGetPlanDePago(plan: any): Observable<any[]> {
    const newSession = Object.assign({}, plan);
    return this.http.post<any[]>(this.urlPostGetPlanDePago, newSession, cudOptions);
  }


}
