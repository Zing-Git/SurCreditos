import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ClientesService } from '../../../modules/servicios/clientes/clientes.service';
import { Session } from '../../../modelo/util/session';
import { LoginService } from '../../../modules/servicios/login/login.service';
import { ElegirCuotasComponent } from '../elegir-cuotas/elegir-cuotas.component';
import { NgxSmartModalService } from 'ngx-smart-modal';
import { ModalCuotasCobranzaComponent } from '../modal-cuotas-cobranza/modal-cuotas-cobranza.component';
import { AsignacionDeCobranza } from '../asignacionDeCobranza';
import { TokenPost } from '../../../modelo/util/token';

@Component({
  selector: 'app-seleccion-de-cliente',
  templateUrl: './seleccion-de-cliente.component.html'
})
export class SeleccionDeClienteComponent implements OnInit {
  @ViewChild(ElegirCuotasComponent) hijo: ElegirCuotasComponent;
  @ViewChild(ModalCuotasCobranzaComponent) hijoModal: ModalCuotasCobranzaComponent;



  dniCobrador: any;
  apellidoCobrador: any;
  session = new Session();
  characters: any[];
  cobranzasAClientes: any[];
  idCobrador: string;

  dniCliente: string;
  nombreApellidoCliente: string;
  direccionCliente: string;






  cobranzaAsignadaACobrador: AsignacionDeCobranza;  // contiene una cobranza de un cobrador
  cobranzasCobradores: any[]; // contiene todas las cobranzas de los cobradores
  asignaciones: any[] = []; // contiene las asignaciones que se van cargando para cobrar
  cantidadCobranzas: number;


  settings = {
    actions: {
      columnTitle: 'Accion',
      add: false,
      delete: false,
      edit: false,
      imprimirPDF: false,
      position: 'right',
      custom: [
        {
          name: 'Carga de Cuotas',
          title: 'Cargar Cobro'
        }
      ],
    },
    columns: {
      'titular.dni': {
        title: 'Dni',
        width: '10%',
        valuePrepareFunction: (cell, row) => { return row.dni }
      },
      nombreCompleto: {
        title: 'Apellido y Nombre',
        width: '20%',
        valuePrepareFunction: (cell, row) => { return row.apellidos + ', ' + row.nombres }
      },
      localidad: {
        title: 'Localidad',
        width: '10%',
        valuePrepareFunction: (cell, row) => { return row.domicilio.localidad }
      },
      calle: {
        title: 'Calle',
        width: '10%',
        valuePrepareFunction: (cell, row) => { return row.domicilio.calle }
      },
      numeroCasa: {
        title: 'Numero',
        width: '10%',
        valuePrepareFunction: (cell, row) => { return row.domicilio.numeroCasa }
      }

    },
    pager: {
      display: true,
      perPage: 10
    },
  };
  constructor(
    private router: ActivatedRoute,
    private loginService: LoginService,
    private clientesService: ClientesService,
    public ngxSmartModalService: NgxSmartModalService
  ) {}

  ngOnInit() {
    const pen: Object = {
      prop1: 'test',
      prop2: true,
      prop4: 327652175423
    };
    this.ngxSmartModalService.setModalData(pen, 'popupOne');

    this.router.params.subscribe(params => {
      this.dniCobrador = params['dni'];
      this.apellidoCobrador = params['apellido'];
      this.idCobrador = params['idCobrador'];

      this.session.token = this.loginService.getTokenDeSession();
      this.cargarClientesActivos();

    });
  }
  cargarClientesActivos() {

    this.clientesService
      .postGetClientesActivos(this.session)
      .subscribe(resp => {
        this.characters = resp['clientes'];
      });
  }

  onCustom(event) {
    // alert(`Custom event '${event.action}' fired on row №: ${event.data.dni}`);
    let evento = (`${event.action}`);
    let dni = (`${event.data.dni}`);
    this.dniCliente = (`${event.data.dni}`);
    this.nombreApellidoCliente = (`${event.data.nombreCompleto}`);
    this.direccionCliente = (`${event.data.localidad}`) + ' - ' + (`${event.data.calle}`) + ' - ' + (`${event.data.numeroCasa}`);

    console.log('NOMBRE CLIENTE: ' + this.nombreApellidoCliente);

    console.log('INGRESO AL SELECCIONAR: ' + dni);
    switch (evento) {
      case 'Carga de Cuotas': {
        console.log( 'DNI a CONSULTAR: ' + dni);
        this.mostrarCuotas(dni);
        break;
      }


    }
  }

  // COMUNICACION CON EL HIJO MODAL-------------------------

  mostrarCuotas(dni: any) {
    this.ngxSmartModalService.getModal('popupOne').open();
    this.hijo.buscarCreditoPorDni(dni);
  }

  enviarMensaje() {
    // this.hijo.saludo('hola desde el padre');
  }



  // finalizar toma datos del hijo modal-cuotas-cobranza
  // es el proceso final, cuando ya elige las cuotas a cobrar viene de nuevo al padre
  // para que se carguen las cuotas y se imprima
  finalizar(event) {
    console.log('viene del hijo de modal-cuotas-cobranza..........');

    this.ngxSmartModalService.getModal('popupTwo').close();
    this.cargarCobranzaACobrador(event);


  }

  // verCuotasCredito recibe datos desde el hijo elegir-cuotas y llama al modal-cuotas pasandole parametros recibidos
  verCuotasDeCredito(event){
    this.ngxSmartModalService.getModal('popupOne').close();
    console.log('viene del hijo de elegir cuota..........');
/*     console.log(event[0]);
    console.log(event[1]);
    console.log(event[2]);
    console.log(event[3]); */

    // this.hijoModal.getDataFromCuotas(this.cuotas, this.charactersCreditos, idCredito, this.session.token);
    this.hijoModal.getDataFromCuotas(event[0], event[1], event[2], event[3]);
    this.ngxSmartModalService.getModal('popupTwo').open();

  }

  cargarCobranzaACobrador(cobros: any) {

    if (!this.cobranzaAsignadaACobrador) { // Encabezado-----------------------------------------------------------
      alert('Primera vuelta: ' + this.cantidadCobranzas);


      this.cantidadCobranzas++;
    } else { // Detalle, se cargan todos los asignaciones de cobranzas de los clientes al cobrador------------------
      alert('Segunda vuelta: '  + this.cantidadCobranzas);
      this.cantidadCobranzas++;
    }


    console.log(cobros);
    this.cobranzaAsignadaACobrador = new AsignacionDeCobranza();

    this.cobranzaAsignadaACobrador.token = cobros[3];
    this.cobranzaAsignadaACobrador.usuario = this.idCobrador;
    this.cobranzaAsignadaACobrador.usuarioCobradorNombre = this.apellidoCobrador;
    this.cobranzaAsignadaACobrador.fechaEmision = (new Date(Date.now())).toString();




    let creditoACobrar = (cobros[1])[0];
    let cuotasId = [];
    let xcuotasAdeudadas = '';
    let xsaldoACobrar = 0;

    cobros[4].forEach(element => {
      console.log('Cuotas Id:' + element._id);
      cuotasId.push(element._id);
      xcuotasAdeudadas = xcuotasAdeudadas + element.orden + ', ';
      xsaldoACobrar = xsaldoACobrar + element.montoPendienteDePago;
    });



    let xcredito = {
      _id: creditoACobrar._id,
      legajoCredito: creditoACobrar.legajoPrefijo + '-' + creditoACobrar.legajo,
      valorDeCuota: creditoACobrar.cuotas[0].MontoTotalCuota, // es el valor de cada cuota que se paga en el credito
      saldoACobrar: xsaldoACobrar, // se suman los montos de las cuotas cargadas.
      interes: xsaldoACobrar - creditoACobrar.cuotas[0].MontoTotalCuota,
      cuotas: cuotasId,   // cuotas a cobrar por el cobrador
      fechaCancelacionCredito: creditoACobrar.cuotas[creditoACobrar.cuotas.length - 1].fechaVencimiento,
      cuotasAdeudadas: xcuotasAdeudadas // enumeracion del numero de cuotas ej: 5,6,7
    };

    let xcreditos = [];
    xcreditos.push(xcredito);

    let asignacion = {
        cliente : {
            dni: this.dniCliente,
            nombreApellido: this.nombreApellidoCliente,
            direccion: this.direccionCliente
        },
        creditos: xcreditos,
    };
    console.log(asignacion);
    this.asignaciones.push(asignacion);


    this.cobranzaAsignadaACobrador.asignaciones = this.asignaciones;
    console.log(this.cobranzaAsignadaACobrador);


  }

}
