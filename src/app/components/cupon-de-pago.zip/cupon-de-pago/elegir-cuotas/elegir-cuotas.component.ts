import { Component, OnInit, ViewChild } from '@angular/core';
import { CreditosService } from "../../../modules/servicios/creditos/creditos.service";
import { Session } from "../../../modelo/util/session";
import { LoginService } from "../../../modules/servicios/login/login.service";
import { NgxSmartModalService } from "ngx-smart-modal";
import swal from "sweetalert2";
import { ModalCuotasCobranzaComponent } from '../modal-cuotas-cobranza/modal-cuotas-cobranza.component';

@Component({
  selector: "app-elegir-cuotas",
  templateUrl: "./elegir-cuotas.component.html",

})
export class ElegirCuotasComponent implements OnInit {
  @ViewChild(ModalCuotasCobranzaComponent) hijoModal: ModalCuotasCobranzaComponent;
  session = new Session();
  charactersCreditos: any[];
  cuotas: any[];

  settings = {
    actions: {
      columnTitle: "Accion",
      add: false,
      delete: false,
      edit: false,
      imprimirPDF: false,
      position: "right",
      custom: [
        {
          name: "mostrarCuotas",
          title: "Seleccionar"
        }
      ]
    },
    columns: {
      nuevoLegajo: {
        title: "Legajo",
        width: "10%",
        filter: false,
        valuePrepareFunction: (cell, row) =>
          row.legajoPrefijo + " - " + row.legajo
      },
      titular: {
        title: 'Nombre titular',
        width: '15%',
        filter: false,
        valuePrepareFunction: (cell, row) =>
          row.titularApellidos + ', ' + row.titularNombres
      },

      totalAPagar: {
        title: 'Monto a Pagar',
        width: '30%',
        filter: false,
        valuePrepareFunction: value => {
          return value === 'totalAPagar'
            ? value
            : Intl.NumberFormat('es-AR', {
                style: 'currency',
                currency: 'ARS'
              }).format(value);
        }
      },
      tipoPlan: {
        title: 'Tipo Plan',
        width: '10%',
        filter: false
      }
    },
    pager: {
      display: true,
      perPage: 5
    },
    noDataMessage: 'El cliente no tiene creditos...'
  };

  constructor(
    private creditosServices: CreditosService,
    private loginService: LoginService,
    private ngxSmartModalService: NgxSmartModalService
  ) {}

  ngOnInit() {
    this.session.token = this.loginService.getTokenDeSession();
  }

  buscarCreditoPorDni(dni: any) {

    if (dni !== '') {
      this.creditosServices.postGetCreditosVigentes(this.session, dni).subscribe(response => {
          let charactersCreditos = response['creditos'];


            // console.log(characters);
          if (typeof charactersCreditos === 'undefined') {
            swal('Advertencia', 'Credito esta pagada o no existe!!', 'warning');
          } else {
            // this.charactersCreditos = characters;
            this.charactersCreditos = JSON.parse(JSON.stringify(charactersCreditos));
            // this.charactersCreditos = Object.assign({}, characters);
          }


        });
    } else {
    }
  }




  onCustom(event) {
    // alert(`Custom event '${event.action}' fired on row №: ${event.data.dni}`);
    let evento = (`${event.action}`);
    const id = (`${event.data._id}`);


    switch (evento) {
      case 'mostrarCuotas': {
        this.mostrarCuotas(id);
        break;
      }


    }
  }

  // COMUNICACION CON EL HIJO MODAL-------------------------

  /* mostrarCuotas(idCreditoElegido: any) {

    this.ngxSmartModalService.getModal('popupTwo').open();
    this.hijoModal.mostrarCuotas(idCreditoElegido, this.charactersCreditos);

  } */

  mostrarCuotas(idCredito: string) {
    let cuotasNoPagas: any[];
    console.log('Mostrando creditos: ' + this.charactersCreditos);
    this.charactersCreditos.forEach(x => {
      if (idCredito == x._id) {
         /*  x.cuotas.forEach(element => {
            if (!element.cuotaPagada){
              cuotasNoPagas.push(element);
            }
          }); */
         this.cuotas = x.cuotas;
      }
    });
    // this.cuotas = cuotasNoPagas;
    // console.log('se estan enviando estas cuotas al hijo: ' + JSON.parse(JSON.stringify(this.cuotas)));
    this.hijoModal.getDataFromCuotas(this.cuotas, this.charactersCreditos, idCredito, this.session.token);
    this.ngxSmartModalService.getModal('popupTwo').open();
    // this.ngOnInit();
  }



 // DATOS RECIBIDOR DEL HIJO ********************************


onOperate(number: number) {
  console.log('valor recibido del hijo es:' + number);
}


}
