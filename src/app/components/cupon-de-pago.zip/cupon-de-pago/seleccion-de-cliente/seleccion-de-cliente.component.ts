import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ClientesService } from '../../../modules/servicios/clientes/clientes.service';
import { Session } from '../../../modelo/util/session';
import { LoginService } from '../../../modules/servicios/login/login.service';
import { ElegirCuotasComponent } from '../elegir-cuotas/elegir-cuotas.component';
import { NgxSmartModalService } from 'ngx-smart-modal';
import { ModalCuotasCobranzaComponent } from '../modal-cuotas-cobranza/modal-cuotas-cobranza.component';

@Component({
  selector: 'app-seleccion-de-cliente',
  templateUrl: './seleccion-de-cliente.component.html'
})
export class SeleccionDeClienteComponent implements OnInit {
  @ViewChild(ElegirCuotasComponent) hijo: ElegirCuotasComponent;



  dniCobrador: any;
  apellidoCobrador: any;
  session = new Session();
  characters: any[];
  cobranzasAClientes: any[];



  settings = {
    actions: {
      columnTitle: 'Accion',
      add: false,
      delete: false,
      edit: false,
      imprimirPDF: false,
      position: 'right',
      custom: [
        {
          name: 'Carga de Cuotas',
          title: 'Cargar Cobro'
        }
      ],
    },
    columns: {
      'titular.dni': {
        title: 'Dni',
        width: '10%',
        valuePrepareFunction: (cell, row) => { return row.dni }
      },
      nombreCompleto: {
        title: 'Apellido y Nombre',
        width: '20%',
        valuePrepareFunction: (cell, row) => { return row.apellidos + ', ' + row.nombres }
      },
      localidad: {
        title: 'Localidad',
        width: '10%',
        valuePrepareFunction: (cell, row) => { return row.domicilio.localidad }
      },
      calle: {
        title: 'Calle',
        width: '10%',
        valuePrepareFunction: (cell, row) => { return row.domicilio.calle }
      },
      numeroCasa: {
        title: 'Numero',
        width: '10%',
        valuePrepareFunction: (cell, row) => { return row.domicilio.numeroCasa }
      }

    },
    pager: {
      display: true,
      perPage: 10
    },
  };
  constructor(
    private router: ActivatedRoute,
    private loginService: LoginService,
    private clientesService: ClientesService,
    public ngxSmartModalService: NgxSmartModalService
  ) {}

  ngOnInit() {
    const pen: Object = {
      prop1: 'test',
      prop2: true,
      prop4: 327652175423
    };
    this.ngxSmartModalService.setModalData(pen, 'popupOne');

    this.router.params.subscribe(params => {
      this.dniCobrador = params['dni'];
      this.apellidoCobrador = params['apellido'];

      this.session.token = this.loginService.getTokenDeSession();
      this.cargarClientesActivos();

    });
  }
  cargarClientesActivos() {

    this.clientesService
      .postGetClientesActivos(this.session)
      .subscribe(resp => {
        this.characters = resp['clientes'];
      });
  }

  onCustom(event) {
    // alert(`Custom event '${event.action}' fired on row №: ${event.data.dni}`);
    let evento = (`${event.action}`);
    let dni = (`${event.data.dni}`);

    console.log('INGRESO AL SELECCIONAR: ' + dni);
    switch (evento) {
      case 'Carga de Cuotas': {
        console.log( 'DNI a CONSULTAR: ' + dni);
        this.mostrarCuotas(dni);
        break;
      }


    }
  }

  // COMUNICACION CON EL HIJO MODAL-------------------------

  mostrarCuotas(dni: any) {
    this.ngxSmartModalService.getModal('popupOne').open();
    this.hijo.buscarCreditoPorDni(dni);
  }

  enviarMensaje() {
    // this.hijo.saludo('hola desde el padre');
  }


  procesaPropagar(event): void {
    alert(event.nombre);
  }



}
