export const environment = {
  production: true,
  LSTORE_USUARIO: 'nombreUsuario',
  LSTORE_TOKEN: 'token',
  LSTORE_ROL: 'rol',
  LSTORE_ROL_PRECEDENCIA: 'precedencia',
  LSTORE_ROL_ID: 'rol_id',
  URL_BASE_WEBSERVICES: 'https://ws-sur-creditos.herokuapp.com',

  /* TOKEN : {
    VALOR: '',
  } */
};
