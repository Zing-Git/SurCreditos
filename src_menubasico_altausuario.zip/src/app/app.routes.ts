import { RouterModule, Routes } from '@angular/router';
import { CrudUsuariosComponent } from './components/usuarios/crud-usuarios/crud-usuarios.component';
import { FormUsuarioComponent } from './components/usuarios/form-usuario/form-usuario.component';
import { CrudClientesComponent } from './components/clientes/crud-clientes/crud-clientes.component';
import { FormClienteComponent } from './components/clientes/form-cliente/form-cliente.component';
import { CrudCreditosComponent } from './components/creditos/crud-creditos/crud-creditos.component';
import { FormCreditoComponent } from './components/creditos/form-credito/form-credito.component';
import { LoginComponent } from './components/login/login.component';

export const appRoutes: Routes = [
  /* { path: "usuarioedit", component: UserEditComponent },
  { path: "usuarioedit/:id", component: UserEditComponent },
  { path: "usuarioedit/:id/:firstName/:lastName", component: UserEditComponent }
 */
{ path: 'crudusuarios', component: CrudUsuariosComponent },
{ path: 'formusuario', component: FormUsuarioComponent },
{ path: 'crudclientes', component: CrudClientesComponent },
{ path: 'formcliente', component: FormClienteComponent },
{ path: 'crudcreditos', component: CrudCreditosComponent },
{ path: 'formcredito', component: FormCreditoComponent },
{ path: 'login', component: LoginComponent },

];
