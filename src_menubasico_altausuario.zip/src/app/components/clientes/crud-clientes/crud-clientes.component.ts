import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-crud-clientes',
  templateUrl: './crud-clientes.component.html',
  styleUrls: ['./crud-clientes.component.css']
})
export class CrudClientesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
