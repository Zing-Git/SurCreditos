import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-crud-creditos',
  templateUrl: './crud-creditos.component.html',
  styleUrls: ['./crud-creditos.component.css']
})
export class CrudCreditosComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
