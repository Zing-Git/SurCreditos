import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-form-credito',
  templateUrl: './form-credito.component.html',
  styleUrls: ['./form-credito.component.css']
})
export class FormCreditoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
