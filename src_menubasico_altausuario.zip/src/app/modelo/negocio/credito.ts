export class Credito {
}
