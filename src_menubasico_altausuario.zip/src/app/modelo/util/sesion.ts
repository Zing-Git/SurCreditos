export class Session {
  public token: string;
  public user: string;
}
