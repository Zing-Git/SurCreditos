import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UsuariosService } from './usuarios/usuarios.service';



@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [],
  providers: [UsuariosService]
})
export class ServiciosModule { }
